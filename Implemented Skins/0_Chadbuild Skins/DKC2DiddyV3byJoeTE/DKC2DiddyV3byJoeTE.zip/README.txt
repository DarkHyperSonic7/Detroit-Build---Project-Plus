Diddy (Brawl-styled DKC2 Sunglasses+Boombox) Model Import (Version 3) - by JoeTE

In the Version 3 Update, I fixed some minor issues with Diddy's fur, optimized all of the model parts, and I made some major improvements to the Boombox.

I've also included 5 recolors for this model (based on Diddy's Brawl color schemes.)